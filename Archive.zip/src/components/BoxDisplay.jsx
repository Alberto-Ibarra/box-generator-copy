import React from 'react'
import "../box.css"
const BoxDisplay = (props) => {
    
    return (
        <div>
            <h1>Colorful Boxes!</h1>
            {
                props.colors.map((color, i)=> {
                    return(
                        <div className="box" key={i} style={{backgroundColor: color.color}}> {color.color}  </div>
                    )
                })
            }
        </div>
    )
}

export default BoxDisplay
