import React from 'react';

const boxes = {
    width: '100px',
    height: '100px',
    padding: '10px',
    border: '2px solid black',
    margin: '10px',
    
}

const Boxes = () => {
        return (<div style={boxes}>{}</div>)
    }


export default Boxes